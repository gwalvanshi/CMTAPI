﻿using System;

using System.Collections.Generic;

using System.Data.Entity.Validation;

using System.Linq;

using System.Net;

using System.Net.Http;

using System.Net.Http.Formatting;

using System.Text;

using System.Web;

using System.Web.Http.Results;



namespace CMTDialer.API

{

    public class ProcessHttpResponse

    {

        public static HttpResponseMessage Sucess<T>(HttpRequestMessage request, T response)

        {



            return request.CreateResponse(HttpStatusCode.OK, response);



        }



        public static HttpResponseMessage Sucess<T>(HttpRequestMessage request, JsonResult<T> response)

        {



            return request.CreateResponse(HttpStatusCode.OK, response, JsonMediaTypeFormatter.DefaultMediaType);



        }



        public static HttpResponseMessage Error(HttpRequestMessage request, Exception ex)

        {

            StringBuilder response = new StringBuilder();

            if (ex is DbEntityValidationException)

            {

                var validationException = ex as DbEntityValidationException;



                foreach (var eve in validationException.EntityValidationErrors)

                {



                    response.AppendFormat("{1} Entity [{0}] has the following validation errors:{1}",

                        eve.Entry.Entity.GetType().Name, "  ");///, eve.Entry.State);

                    foreach (var ve in eve.ValidationErrors)

                    {

                        response.AppendFormat(" [{0}] :[{1}] ",

                            ve.PropertyName, ve.ErrorMessage);

                    }

                }





                MyLogger.Error(response.ToString());



            }

            else

            {

                response.AppendLine(ex.Message);

                MyLogger.Error(ex.Message + ex.StackTrace);

                while (ex.InnerException != null)

                {

                    ex = ex.InnerException;

                    response.AppendLine(ex.Message);

                }





            }



            MyLogger.Error(response.ToString());





            return request.CreateResponse(HttpStatusCode.BadRequest, response.ToString());



            //  Common.MyLogger.Error(ex);





            //    return   request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);



        }





    }

}

