﻿using CMTDialer.Manager;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Net;

using System.Net.Http;

using System.Web;

using System.Web.Http.Controllers;

using System.Web.Http.Filters;



namespace CMTDialer.API

{

    public class AuthorizationRequiredAttribute : ActionFilterAttribute

    {

        private const string Token = "Authorization";
        private const string AccessKey = "AccessKey";
        private const string SecreteKey = "SecreteKey";

        public string TokenId { get; set; }

        public string Roles { get; set; }

        public override void OnActionExecuting(HttpActionContext filterContext)

        {

            //  Get API key provider



            LoginManager provider = new LoginManager();

            //filterContext.ControllerContext.Configuration

            //.DependencyResolver.GetService(typeof(ITokenServices)) as ITokenServices;



            if (filterContext.Request.Headers.Contains(Token))

            {

                var tokenValue = filterContext.Request.Headers.Authorization.Parameter;

                TokenId = tokenValue;

                if (tokenValue == string.Empty)

                {
                   
                    var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Invalid Token.kinldy contact to admin." };

                    filterContext.Response = responseMessage;


                }

                // Validate Token

                else if (!provider.ValidateToken(tokenValue))

                {



                    var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Invalid request/token expired.kinldy contact to admin" };

                    filterContext.Response = responseMessage;

                }

                else

                {

                    int rolId = provider.UserRoleBasedonToken(tokenValue);

                    if (!string.IsNullOrEmpty(Roles))

                    {

                        if (!Roles.Contains(rolId.ToString()))

                        {

                            var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "You are not authrized to do any action.kinldy contact to admin" };

                            filterContext.Response = responseMessage;

                        }

                    }

                }



            }

            else

            {

                var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "Invalid key.kinldy contact to admin" };

                filterContext.Response = responseMessage;

            }



            base.OnActionExecuting(filterContext);



        }

    }



}