﻿using CMTDialer.Manager;
using CMTDialer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CMTDialer.API.Controllers
{
    [AuthorizationRequiredAttribute]
    public class DialerController : ApiController
    {
        [HttpPost]
        [Route("api/AddDiallerData")]
        public HttpResponseMessage AddDiallerData(LoginEntity objlogin)
        {
            UserManager objUserAuthBLL = new UserManager();
            try
            {

                var retunData = objUserAuthBLL.SaveUpdateUser(objlogin);
                return ProcessHttpResponse.Sucess(Request, retunData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }

        }
    }
}
