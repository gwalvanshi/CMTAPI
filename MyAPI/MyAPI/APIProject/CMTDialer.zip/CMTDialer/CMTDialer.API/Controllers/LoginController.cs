﻿using CMTDialer.Model;

using CMTDialer.Manager;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Net;

using System.Net.Http;

using System.Web.Http;



namespace CMTDialer.API.Controllers

{

    public class LoginController : ApiController

    {

        [Route("api/login")]

        [HttpPost]

        public HttpResponseMessage Login(LoginEntity objlogin)

        {

            LoginManager objLoginBL = new LoginManager();


            try

            {



                LoginEntity returnData = null;



                returnData = objLoginBL.AuthenticateUser(objlogin.UserName, objlogin.Password);



                if (returnData != null)

                {

                    if (returnData.userId > 0)

                    {

                        TokenEntity objToken = objLoginBL.GenerateToken(returnData.userId);

                        returnData.authToken = objToken.authToken;

                        returnData.issuedOn = objToken.issuedOn;

                        returnData.expiresOn = objToken.expiresOn;

                    }

                    else

                    {

                        return ProcessHttpResponse.Error(Request, new Exception("User details not exists"));

                    }

                }

                else

                {

                    return ProcessHttpResponse.Error(Request, new Exception("User details not exists"));

                }



                return ProcessHttpResponse.Sucess(Request, returnData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }





        }





        [HttpPost]

        [Route("api/AuthenticateUserCredentials")]

        public HttpResponseMessage AuthenticateUserCredentials(LoginEntity objlogin)

        {

            LoginManager objUserAuthBLL = new LoginManager();

            try

            {

                var retunData = objUserAuthBLL.AuthenticateUserCredentials(objlogin.UserName, objlogin.Password);

                return ProcessHttpResponse.Sucess(Request, retunData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }

        }

        [HttpPost]

        [Route("api/ChangePassword")]

        public HttpResponseMessage ChangePassword(LoginEntity objlogin)

        {

            LoginManager objUserAuthBLL = new LoginManager();

            try

            {

                var retunData = objUserAuthBLL.ChangePassword(objlogin.UserName, objlogin.Password);

                return ProcessHttpResponse.Sucess(Request, retunData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }

        }

        [HttpPost]

        [Route("api/CheckIfPasswordReused")]

        public HttpResponseMessage CheckIfPasswordReused(LoginEntity objlogin)

        {

            LoginManager objUserAuthBLL = new LoginManager();

            try

            {



                var retunData = objUserAuthBLL.CheckIfPasswordReused(objlogin.UserName, objlogin.Password);

                return ProcessHttpResponse.Sucess(Request, retunData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }

        }

        [HttpPost]

        [Route("api/CheckIfFirstTimeLogin")]

        public HttpResponseMessage CheckIfFirstTimeLogin(LoginEntity objlogin)

        {

            LoginManager objUserAuthBLL = new LoginManager();

            try

            {

                var retunData = objUserAuthBLL.CheckIfFirstTimeLogin(objlogin.UserName);

                return ProcessHttpResponse.Sucess(Request, retunData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }

        }

        [HttpPost]

        [Route("api/CheckIfPassExpired")]

        public HttpResponseMessage CheckIfPassExpired(LoginEntity objlogin)

        {

            LoginManager objUserAuthBLL = new LoginManager();

            try

            {

                var retunData = objUserAuthBLL.CheckIfPassExpired(objlogin.UserName, objlogin.Days);

                return ProcessHttpResponse.Sucess(Request, retunData);

            }

            catch (Exception ex)

            {

                return ProcessHttpResponse.Error(Request, ex);

            }

        }

    }

}

