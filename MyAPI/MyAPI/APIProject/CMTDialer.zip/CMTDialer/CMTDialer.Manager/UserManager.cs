﻿using CMTDialer.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMTDialer.Manager
{
   public class UserManager
    {
        public int SaveUpdateUser(LoginEntity objLoginEntity)
        {                


           

            int row = 0;

            try

            {

                

               SqlParameter[] param = new SqlParameter[9];

                param[0] = new SqlParameter("@FirstName", objLoginEntity.FirstName);

                param[1] = new SqlParameter("@LastName", objLoginEntity.LastName);

                param[2] = new SqlParameter("@UserName", objLoginEntity.UserName);

                param[3] = new SqlParameter("@Password", objLoginEntity.Password);
                param[4] = new SqlParameter("@PhoneNo", objLoginEntity.PhoneNo);
                param[5] = new SqlParameter("@MobileNo", objLoginEntity.MobileNo);
                param[6] = new SqlParameter("@Email", objLoginEntity.Email);
                param[7] = new SqlParameter("@RoleId", objLoginEntity.RoleID);
                param[8] = new SqlParameter("@CreatedBy", objLoginEntity.CreatedBy);              
                row = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "sp_SaveUserDetails", param);
        
            }

            catch (Exception ex)

            {

                throw ex;

            }

            return row;
        }
    }
}
