﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMTDialer.Model;

namespace CMTDialer.Manager

{

    public class LoginManager

    {

        public int AuthenticateUserCredentials(string username, string encryptedPwd)

        {

            DataSet ds = new DataSet();

            string commandText = "Proc_AuthenticateUserCredentials";

            try

            {

                SqlParameter[] param = new SqlParameter[2];

                param[0] = new SqlParameter("@Username", username);

                param[1] = new SqlParameter("@EncryptedPassword", encryptedPwd);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);



                return Convert.ToInt16(ds.Tables[0].Rows[0][0]);

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }

        public LoginEntity AuthenticateUser(string username, string encryptedPwd)

        {

            DataSet ds = new DataSet();

            LoginEntity objLogin = new LoginEntity();

            string commandText = "Proc_AuthenticateUser";

            try

            {

                SqlParameter[] param = new SqlParameter[2];

                param[0] = new SqlParameter("@Username", username);

                param[1] = new SqlParameter("@EncryptedPassword", encryptedPwd);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);



                if (ds != null)

                {

                    if (ds.Tables.Count > 0)

                    {

                        if (ds.Tables[0].Rows.Count > 0)

                        {

                            objLogin.userId = Convert.ToInt64(ds.Tables[0].Rows[0]["UserID"]);

                            objLogin.RoleID = Convert.ToInt64(ds.Tables[0].Rows[0]["RoleID"]);

                            objLogin.EmployeeName = Convert.ToString(ds.Tables[0].Rows[0]["FirstName"] + " " + ds.Tables[0].Rows[0]["LastName"]);

                        }

                    }

                }

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return objLogin;

        }



        public bool ChangePassword(string username, string encryptedPwd)

        {

            DataSet ds = new DataSet();

            int row = 0;

            try

            {

                SqlParameter[] param = new SqlParameter[2];

                param[0] = new SqlParameter("@Username", username);

                param[1] = new SqlParameter("@EncryptedPassword", encryptedPwd);

                row = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "Proc_ChangePassword", param);

                return row > 0;

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }

        public LoginEntity AuthenticateLDAPUser(string username)

        {

            DataSet ds = new DataSet();

            LoginEntity objLogin = new LoginEntity();

            string commandText = "Proc_AuthenticateLDAPUser";

            try

            {

                SqlParameter[] param = new SqlParameter[1];

                param[0] = new SqlParameter("@Username", username);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);



                if (ds != null)

                {

                    if (ds.Tables.Count > 0)

                    {

                        if (ds.Tables[0].Rows.Count > 0)

                        {

                            objLogin.userId = Convert.ToInt64(ds.Tables[0].Rows[0]["UserID"]);

                            objLogin.RoleID = Convert.ToInt64(ds.Tables[0].Rows[0]["RoleID"]);



                        }

                    }

                }

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return objLogin;

        }



        public bool CheckIfPasswordReused(string username, string encryptedPwd)

        {

            DataSet ds = new DataSet();

            string commandText = "Proc_CheckIfReusingPassword";

            try

            {

                SqlParameter[] param = new SqlParameter[2];

                param[0] = new SqlParameter("@Username", username);

                param[1] = new SqlParameter("@EncryptedPassword", encryptedPwd);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);



                return Convert.ToBoolean(ds.Tables[0].Rows[0][0]);

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }



        public bool CheckIfFirstTimeLogin(string userName)

        {

            DataSet ds = new DataSet();

            string commandText = "Proc_CheckIfFirstTimeLogin";

            try

            {

                SqlParameter[] param = new SqlParameter[1];

                param[0] = new SqlParameter("@Username", userName);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);



                return Convert.ToBoolean(ds.Tables[0].Rows[0][0]);

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }



        public bool CheckIfPassExpired(string userName, int days)

        {

            DataSet ds = new DataSet();

            string commandText = "Proc_CheckIfPassExpired";

            try

            {

                SqlParameter[] param = new SqlParameter[2];

                param[0] = new SqlParameter("@Username", userName);

                param[1] = new SqlParameter("@Days", days);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);



                return Convert.ToBoolean(ds.Tables[0].Rows[0][0]);

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }



        public TokenEntity GenerateToken(Int64 userId)

        {

            string token = Guid.NewGuid().ToString();

            DateTime issuedOn = DateTime.Now;

            DateTime expiredOn = DateTime.Now.AddMinutes(

            Convert.ToDouble(ConfigurationManager.AppSettings["AuthTokenExpiryInMinute"]));

            var tokendomain = new TokenEntity

            {

                userId = userId,

                authToken = token,

                issuedOn = issuedOn,

                expiresOn = expiredOn

            };





            DataSet ds = new DataSet();

            int row = 0;

            try

            {

                SqlParameter[] param = new SqlParameter[4];

                param[0] = new SqlParameter("@UserId", userId);

                param[1] = new SqlParameter("@AuthToken", token);

                param[2] = new SqlParameter("@IssuedOn", issuedOn);

                param[3] = new SqlParameter("@ExpiresOn", expiredOn);

                row = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "spSaveToken", param);



            }

            catch (Exception ex)

            {

                throw ex;

            }

            return tokendomain;

        }



        /// <summary>

        /// Method to validate token against expiry and existence in database.

        /// </summary>

        /// <param name="tokenId"></param>

        /// <returns></returns>

        public bool ValidateToken(string tokenId)

        {

            bool isValid = false;

            DataSet ds = new DataSet();

            string commandText = "spGetToken";

            try

            {





                SqlParameter[] param = new SqlParameter[2];

                param[0] = new SqlParameter("@AuthToken", tokenId);

                param[1] = new SqlParameter("@todayDate", DateTime.Now);

                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);

                if (ds != null)

                {

                    if (ds.Tables[0] != null)

                    {

                        if (ds.Tables[0].Rows.Count > 0)

                        {

                            isValid = true;

                        }

                    }

                }

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return isValid;



        }
        public DataTable GetUserPermission(int userId, string operation,string screenId)

        {

            DataTable dt = new DataTable();

            string commandText = "Proc_GetPermission";

            try

            {

                SqlParameter[] param = new SqlParameter[3];

                param[0] = new SqlParameter("@UserId", userId);
                param[1] = new SqlParameter("@ScreenID", screenId);
                param[2] = new SqlParameter("@Operation", operation);

               var ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);

                if(ds!=null)
                {
                    if(ds.Tables.Count>0)
                    {
                        dt= ds.Tables[0];
                    }
                }                             

            }

            catch (Exception ex)

            {

                throw ex;

            }
            return dt;
        }
        public int UserRoleBasedonToken(string tokenId)

        {



            DataSet ds = new DataSet();

            string commandText = "spUserRoleBasedonToken";

            try

            {



                SqlParameter[] param = new SqlParameter[1];

                param[0] = new SqlParameter("@AuthToken", tokenId);



                ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);

                return Convert.ToInt16(ds.Tables[0].Rows[0][0]);

            }

            catch (Exception ex)

            {

                throw ex;

            }





        }

    }

}